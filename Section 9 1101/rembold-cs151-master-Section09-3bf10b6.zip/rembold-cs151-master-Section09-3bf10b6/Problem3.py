

def create_cumulative_histogram(hist):
    """Creates a cumulative histogram from an array of counts

    Arguments:
        hist (list of ints): a histogram of counts
    Returns:
        (list of ints): the cumulative histogram counts
    """
    #! Your code here!



if __name__ == '__main__':
    hist = [0,0,0,0,1,0,2,2,4,2,1]
    print(create_cumulative_histogram(hist))

