# Section 09 
Template resources for problems for Section 09, dealing with ImageShop problems.
