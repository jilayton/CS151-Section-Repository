# Section 07
This starting template revolves around animating a simple Pacman scene, and practices using several techniques that will be vital to Project 2: Breakout.
