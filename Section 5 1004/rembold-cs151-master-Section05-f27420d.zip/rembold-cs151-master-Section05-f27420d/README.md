# Section 05
There only a single template problem in this repository, as the rest of this section is dedicated to reviewing material and the practice exams for the first midterm.
