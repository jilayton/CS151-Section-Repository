# File: Prob1.py

"""
This program draws a Tic-Tac-Toe board in the center of the
graphics window.
"""

from pgl import GWindow, GLine

# Constants

GWINDOW_WIDTH = 500
GWINDOW_HEIGHT = 300
BOARD_SIZE = 240

# Main program

def tic_tac_toe_board():
    """
    Draws a Tic-Tac-Toe board.  The program centers the board
    on the window and computes the coordinates of the lines
    from the constant BOARD_SIZE.
    """











if __name__ == "__main__":
    tic_tac_toe_board()
