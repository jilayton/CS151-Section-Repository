# Section03
Section materials for week 3 on control statements, algorithms, and strings.
