# Console Box

def draw_console_box(width, height):
    """
    Draws a box to the console of the desired coordinates.

    Arguments:
        width (int): Number of characters wide the box should be
        height (int): Number of characters high the box should be
    Returns:
        None
    """
    # Your code here :)



if __name__ == '__main__':
    draw_console_box(52, 6)
